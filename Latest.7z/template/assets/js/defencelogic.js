function myFunction() {
    window.print();
}

$(document).ready(function () {
    // Handler for .ready() called.
    // Hide the first item
  $('.collapse').collapse('hide');
});



function myFunction() {
    window.print();
}

// $(document).ready(function () {
//     // Handler for .ready() called.
//     var collapseElementList = [].slice.call(document.querySelectorAll('.collapse'))
//     var collapseList = collapseElementList.map(function (collapseEl) {
//         if (collapseEl.Collapse == "true") {
//             collapseEl.Collapse == false;
//             console.log("SSSS")
//         }
//         return collapseList;
//     })
// });
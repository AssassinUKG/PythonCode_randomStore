function update() {
    var ele = document.getElementById("test2").value;
    var data = ele;
    data = data.replace(/^\n|\n$/g, '');
    data = data.replace(/<\\\/script>/g, "<\/script> ")
    var res = document.getElementById("updateme");
    console.log(data);
    res.innerHTML = "Results: " + data;
}

function search() {
    var result = document.getElementById("searchText").value;
    if (result) {
        var retString = "You searched for <span class=\"text-success\">" + result + "</span>!<br>";
        retString += "Results: none";
        document.getElementById("searchResults").innerHTML = retString;

    } else {
        document.getElementById("searchResults").innerHTML = "Results: none...";
    }
}
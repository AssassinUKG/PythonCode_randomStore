import re
import numpy
# testString = """<ul>
#                             <li style="font-size: 14px;">Total Findings:&nbsp;<span class="spanFindings" style="font-size: 14px;">34</span></li>
#                             <li style="font-size: 14px;">Total Critical:&nbsp;1</li>
#                             <li style="font-size: 14px;">Total High:&nbsp;<span class="spanFindings" style="font-size: 14px;">8</span></li>
#                             <li style="font-size: 14px;">Total Medium: 20</li>
#                             <li style="font-size: 14px;">Total Low:&nbsp;<span class="spanFindings" style="font-size: 14px;">5</span></li>
#                             <li style="font-size: 14px;">Total Info:&nbsp;<span class="spanFindings" style="font-size: 14px;">0</span></li>
#                         </ul>"""
# regxStr = "<ul>(\n\s.*){5}"
# x = re.search(regxStr, testString)
# print(x.groups(1))

# list1 = [1, 2, 3, 4, 5, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
#          16, 1, 2, 3, 4, 5, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

# for i in range(0, len(list1), 6):
#     print(list1[i:i+6])


import numpy as np


class Report(object):
    def __init__(self, hostname, id):
        self.hostname = hostname
        self.id = id

    def host_name(self, name):
        self.name = name
        return self.name

    def host_id(self, id):
        self.id = id
        return self.id


ReportArray = np.ndarray((10,), dtype=np.object)


for f in ReportArray:
    print(f)

for i in range(0, len(ReportArray)):
    ReportArray[i] = Report(f"Name {i}", i)
    print(ReportArray[i].hostname)

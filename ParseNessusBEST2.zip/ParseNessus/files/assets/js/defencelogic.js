function myFunction() {
    window.print();
}

function change_checkbox(obj, name) {
    if (obj.checked) {
        toggle_by_class(name, true);
    } else {
        toggle_by_class(name, false);
    }
}
// change_checkbox(this, "criticalbg")

function toggle_by_class(cls, on) {
    var lst = document.getElementsByClassName(cls);
    for(var i = 0; i < lst.length; ++i) {
        lst[i].style.display = on ? '' : 'none';
    }
}

function hidevuln(obj, name) {
    var list = document.getElementsByClassName(name);
    for (var i = 0; i < list.length; i++) {
        var parernt = list[i].parentNode;
        var parernt2 = parernt.parentNode;
        var parernt3 = parernt2.parentNode;
        var parernt4 = parernt3.parentNode;
        //     accordion atblist
        //     parernt2.style.display === "block";
        if (obj.checked) {
            parernt4.style.display = "";
        } else {
            parernt4.style.display = "none";
        }

        console.log(parernt4);
    }
}
// $(document).ready(function () {
//     // Handler for .ready() called.
//     // Hide the first item
//   $('.collapse').collapse('hide');
// });

// Note always replace assets/ with ../assets for the css files etc.